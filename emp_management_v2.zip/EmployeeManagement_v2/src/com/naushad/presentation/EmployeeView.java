package com.naushad.presentation;

import java.util.Scanner;

import com.naushad.dao.EmployeeDAO;
import com.naushad.dao.EmployeeDAOImpl;
import com.naushad.model.Employee;
import com.naushad.service.EmployeeService;
import com.naushad.service.EmployeeServiceImpl;

public class EmployeeView {
	private Scanner scanner = new Scanner(System.in);
	private Employee[] employees = null;

	private EmployeeService employeeService = new EmployeeServiceImpl();

	public EmployeeView() {
		diplayOptions();
	}

	private void diplayOptions() {
		System.out.println("===  Options ===");
		System.out.println("1. Add Employee");
		System.out.println("2. Delete Employee");
		System.out.println("3. Update Employee");
		System.out.println("4. Calculate Salary");
		System.out.println("5. Display Employee");
		System.out.println("6. Display All Employees");
		System.out.println("7. Exit");
		System.out.println("Enter Choice : ");
		int choice = scanner.nextInt();
		doOption(choice);
	}

	private void doOption(int choice) {
		switch (choice) {
		case 1: {
			addEmployee();
			diplayOptions();
			break;
		}
		case 5: {
			displayEmployee();
			diplayOptions();
			break;
		}
		case 6: {
			displayEmployees();
			diplayOptions();
			break;
		}
		case 7: {
			System.out.println("Thanks for Using the Application");
			System.exit(0);
			break;
		}
		default:
			throw new IllegalArgumentException("Unexpected value: " + choice);
		}
	}

	private void displayEmployee() {
		System.out.println("Enter Employee Id : ");
		Integer empId = scanner.nextInt();
		Employee employeeFromDB = employeeService.getEmployeeById(empId);
		if (employeeFromDB == null) {
			System.out.printf("Sorry , %d does not exist \n", empId);
		} else {
			System.out.println("=== Employee Record ===");
			System.out.println(employeeFromDB.getEmpId() + "\t" + employeeFromDB.getEmpName());
			System.out.println("=======================");
		}
	}

	private void addEmployee() {
		employees = new Employee[10];
		int employeeCount = 0;
		boolean option = false;
		do {
			System.out.println("=== Add Employee ===");
			System.out.println("Enter Employee Id : ");
			int empId = scanner.nextInt();
			System.out.println("Enter Employee Name : ");
			scanner.nextLine();
			String empName = scanner.nextLine();
			employees[employeeCount] = new Employee(empId, empName);
			System.out.println("Add More Employees ? Y/N");
			option = scanner.next().equalsIgnoreCase("y");
			if (option) {
				employeeCount++;
			}
		} while (option);
		int x = employeeService.saveEmployee(this.employees);
		System.out.println(x);
	}

	private void displayEmployees() {
		Employee[] employees = employeeService.getAllEmployees();
		System.out.println("=== Employee Record ===");
		System.out.println(" ID \t NAME");
		for (Employee employee : employees) {
			if (employee != null) {
				System.out.println(employee.getEmpId() + "\t" + employee.getEmpName());
			}
		}
		System.out.println("=====================");

	}
}
