package com.naushad.service;

import com.naushad.model.Employee;

public interface EmployeeService {
	
	public int saveEmployee(Employee...employees);
	public Employee[] getAllEmployees();
	public Employee getEmployeeById(Integer empId);

}
