package com.nau.controller;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.Console;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;

import com.nau.service.PasswordValidation;

@WebServlet("/emp/login")
public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");

		String userId = request.getParameter("userid");
		String password = request.getParameter("password");
		System.out.println(userId + " : " + password);
		PrintWriter out = response.getWriter();
		// if (userId.equals(password)) {
		PasswordValidation validation = new PasswordValidation();
		boolean res = validation.verifyPassword(userId, password);
		if (res) {
			RequestDispatcher welcome = request.getRequestDispatcher("/WEB-INF/jspfiles/welcome.jsp");
			welcome.forward(request, response);
			// out.println("<h1>Welcome , " +userId.toUpperCase() + "</h1>");
		} else {
			// out.println("<h1>Sorry, Invalid user : " +userId + "</h1>");
			String error = "Sorry, Invalid user : " + userId;
			RequestDispatcher login = request.getRequestDispatcher("/staticviews/login.jsp");
			request.setAttribute("errormessage", error);//
			login.forward(request, response);
		}
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
		// Enumeration<String> enumeration= request.getParameterNames();
//		while(enumeration.hasMoreElements()) {
//			String key = enumeration.nextElement();
//			String val =  request.getParameter(key);
//			System.out.println(key + " : " + val);
//		}
	}
}
