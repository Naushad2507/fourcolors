package com.nau.model;

public record User(String userId, String password) {
	
	

}
