package com.nau.service;

import com.nau.model.User;

public class PasswordValidation {
	
	public boolean verifyPassword(String userId,String password ) {
		
		VerifyUserDAO dao = new VerifyUserDAO();
		User user =  dao.verify(userId, password);
		if(user!=null) {
			if(user.password().equals(password)) {
				return true;
			}
		}
		
		return false;
	}
}