package com.nau.service;

import com.nau.model.User;

public class VerifyUserDAO {
	
	public User verify(String userId, String password) {
		// select  * from table where userid--= userid;
		
		return new User(userId,password);
		
	}

}
