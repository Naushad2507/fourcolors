package com.nau;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

import com.mysql.cj.jdbc.Driver;
import com.nau.model.User;

public class JdbcDemo {

	public static void main(String[] args) throws FileNotFoundException, IOException {

		User user = new User(1, "asf", "ASD");
		System.out.println(user);
		
		// DriverManager.registerDriver(new Driver());
//		Properties properties = new Properties();
//		Connection con = null;
//		try (FileReader fr = new FileReader("dbconnection.properties")) {
//			properties.load(fr);
//			String url = properties.getProperty("url");// "jdbc:mysql://localhost:3306";
//			String username = properties.getProperty("username");// naushad"; // root
//			String password = properties.getProperty("password");// naushad";
//			String database = properties.getProperty("database");// fourpoints";
//			con = DriverManager.getConnection(url + "/"+ database, username, password);
//		} catch (SQLException e) {
//			e.printStackTrace();
//		}
//		String sql = "insert into user values(3,'nau25','naushad akhtar')"; // SQL DML
//		try {
//			Statement st = con.createStatement();
//			int count = st.executeUpdate(sql);
//			System.out.println(count);
//			System.out.println("Done");
//		} catch (SQLException e) {
//			e.printStackTrace();
//		}

		// http://localhost
		// ftp://localhost
		// smtp ://

	}

}
