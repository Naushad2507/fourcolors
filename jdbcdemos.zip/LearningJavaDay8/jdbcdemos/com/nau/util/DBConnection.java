package com.nau.util;

import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DBConnection {

	private static Connection connection;

	private DBConnection() {
	}
	static {
		Properties properties = new Properties();
		try (FileReader fr = new FileReader("dbconnection.properties")) {
			properties.load(fr);
			String url = properties.getProperty("url");// "jdbc:mysql://localhost:3306";
			String username = properties.getProperty("username");// naushad"; // root
			String password = properties.getProperty("password");// naushad";
			String database = properties.getProperty("database");// fourpoints";
			connection = DriverManager.getConnection(url + "/" + database, username, password);
		} catch (SQLException | IOException e) {
			e.printStackTrace();
		}
	}

	public static Connection getConnection() {
		return connection;
	}

}
