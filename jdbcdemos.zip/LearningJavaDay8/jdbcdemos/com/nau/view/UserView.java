package com.nau.view;

import java.util.List;

import com.nau.dao.UserDAO;
import com.nau.dao.UserDAOImpl;
import com.nau.model.User;

public class UserView {
	
	public static void main(String[] args) {
		
		User user = new User(6, "Papa", "Rahul Gupta");
		UserDAO dao = new UserDAOImpl();
		//dao.addUser(user);
		List<User> users = dao.getUsers();
		users.forEach(System.out::println);
	}

}
