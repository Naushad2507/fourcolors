package com.nau.dao;

import java.util.List;

import com.nau.model.User;

public interface UserDAO {
	
	void addUser(User user);
	List<User> getUsers();

}
