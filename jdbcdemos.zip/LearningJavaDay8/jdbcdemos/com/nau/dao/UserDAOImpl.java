package com.nau.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.nau.model.User;
import com.nau.util.DBConnection;

public class UserDAOImpl implements UserDAO {

	private Connection connection = DBConnection.getConnection();

	@Override
	public List<User> getUsers() {

		String sql = "select * from user";
		try (PreparedStatement ps = connection.prepareStatement(sql)) {
			ResultSet rs = ps.executeQuery();
			List<User> users = new ArrayList<>();
			while (rs.next()) {
				User user = new User(rs.getInt(1), rs.getString(2), rs.getString(3));
				users.add(user);
			}
			return users;
//			ResultSetMetaData rsmd =  rs.getMetaData();
//			int col_count = rsmd.getColumnCount();
//			String n = rsmd.getTableName(1);
//			System.out.println(col_count + " \t " + n);

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public void addUser(User user) {
		// s.save(user)
		Integer userid = user.userid();
		String password = user.password();
		String username = user.username();
		String sql = "insert into user values(?,?,?)";
		try (PreparedStatement ps = connection.prepareStatement(sql)) {
			ps.setInt(1, userid);
			ps.setString(2, password);
			ps.setString(3, username);
			int count = ps.executeUpdate();
			System.out.println(count + " records saved");
		} catch (SQLException e) {
			e.printStackTrace();
		}

		// String sql = "insert into user values(" + userid + ",'" + password + "','" +
		// username + "')";
//		try (Statement st = connection.createStatement()) {
//			int count = st.executeUpdate(sql);
//			System.out.println(count + " records saved");
//		} catch (SQLException e) {
//			e.printStackTrace();
//		}
	}
}
