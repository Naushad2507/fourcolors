package com.nau;

import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ExecutorThreadDemo {
	public static void main(String[] args) {
		ExecutorService executorService = Executors.newCachedThreadPool();
	}
}
