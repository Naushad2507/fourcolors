package com.nau.model;

// lombok

public record User(int userid, String password, String username) {

	public User {
		
	}

	public User(int userid, String password) {
		this(userid, password, null);
	}
}
