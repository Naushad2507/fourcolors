/**
 * 
 */
/**
 * 
 */
module LearningJavaDay8 {
	requires java.sql;
	requires mysql.connector.j;
}