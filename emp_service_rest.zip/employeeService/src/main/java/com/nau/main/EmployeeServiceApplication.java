package com.nau.main;

import javax.ws.rs.ApplicationPath;

import org.glassfish.jersey.server.ResourceConfig;

@ApplicationPath("/employeeapp")
public class EmployeeServiceApplication extends ResourceConfig{
	
	public EmployeeServiceApplication() {
		packages("com.nau.controller");
	}

}
