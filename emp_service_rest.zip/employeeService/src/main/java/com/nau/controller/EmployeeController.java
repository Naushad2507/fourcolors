package com.nau.controller;

import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.nau.model.EmployeeDTO;

@Path("/employee")  // http://localhost:8080/employeeService/employeeapp/employee
public class EmployeeController {
	
	@GET()
	@Path("/")
	public String checkController() {
		return "All Ok with employee";
	}
	
	@GET()
	@Path("/getemployeebyid_string/{id}") // http://localhost:8080/employeeService/employeeapp/employee/getemployeebyid_string/{id}
	@Produces(MediaType.TEXT_PLAIN)
	public String getEmployeeByIdString(@PathParam("id") Integer id) {
		return new EmployeeDTO(id,"naushad").toString();
	} 
	
	@GET()
	@Path("/getemployeebyid_entity/{id}") // http://localhost:8080/employeeService/employeeapp/employee/getemployeebyid_entity/{id}
	@Produces(MediaType.APPLICATION_JSON)
	public EmployeeDTO getEmployeeByIdEntity(@PathParam("id") Integer id) {
		return new EmployeeDTO(id,"naushad");
	} 
	
	@GET()
	@Path("/getemployeebyid_response/{id}") // http://localhost:8080/employeeService/employeeapp/employee/getemployeebyid_response/{id}
	public Response getEmployeeByIdResponse(@PathParam("id") Integer id) {
		EmployeeDTO dto = new EmployeeDTO(id,"naushad");
		Response response = Response.ok(dto).build();
		return response;
	} 
	
	@GET
	@Path("/getemployeebyid_response2/{id}") // http://localhost:8080/employeeService/employeeapp/employee/getemployeebyid_response/{id}
	public Response getEmployeeByIdResponse2(@PathParam("id") Integer id) {
		EmployeeDTO dto = new EmployeeDTO(id,"naushad");
		// Response response = Response.ok(dto).build();
		 Response response = Response.ok().entity(dto).build();
		return response;
	} 
	
	@GET
	@Path("/getallemployees")// http://localhost:8080/employeeService/employeeapp/employee/getallemployees
	@Produces(MediaType.APPLICATION_JSON)
	public Response getAllEmployees(){
		List<EmployeeDTO> employeeDTOs = new ArrayList<>();
		employeeDTOs.add(new EmployeeDTO(1,"nau1"));
		employeeDTOs.add(new EmployeeDTO(2,"nau2"));
		employeeDTOs.add(new EmployeeDTO(3,"nau3"));
		employeeDTOs.add(new EmployeeDTO(4,"nau4"));
		employeeDTOs.add(new EmployeeDTO(5,"nau5"));

		return Response.ok().entity(employeeDTOs).header("Access-Control-Allow-Origin", "*").build();
		//return employeeDTOs;
	}
}
