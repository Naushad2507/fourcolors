package com.nau.util;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Logger;

import com.mysql.cj.jdbc.Driver;

public class DBConnection {

	private static Connection connection;
	private  static Logger logger = Logger.getLogger(DBConnection.class.getName());
	static {
		try {
			DriverManager.registerDriver(new Driver());
			String url = "jdbc:mysql://localhost:3306/fourpoints";
			connection = DriverManager.getConnection(url,"naushad","naushad");
			logger.info("Connection Done");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	public static Connection getConnection() {
		return connection;
	}
	public static void main(String[] args) {
		DBConnection.getConnection();
	}
}
