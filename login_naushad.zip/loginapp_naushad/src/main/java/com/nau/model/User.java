package com.nau.model;

public record User(Integer userId,String password) {

}
