package com.nau.model;

public record UserVO (String username,String password){
	
	}
