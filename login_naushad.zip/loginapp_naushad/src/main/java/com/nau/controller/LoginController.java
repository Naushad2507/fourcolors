package com.nau.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

import com.nau.model.User;
import com.nau.service.LoginService;

@WebServlet("/lc")
public class LoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.getRequestDispatcher("/WEB-INF/jsp/loginpage.jsp").forward(request, response);
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		Integer userId = Integer.parseInt(request.getParameter("userId"));
		String password = request.getParameter("password");
		User user = new User(userId, password);
		LoginService loginService = new LoginService();
		String res = loginService.validateUser(user);
		if(res!=null) {
			System.out.println("before despatch");
			//out.print("page before despatch");
			request.setAttribute("username", res);
			request.getRequestDispatcher("/WEB-INF/jsp/welcome.jsp").forward(request, response);
			System.out.println("after despacth");
			//out.print("page after despatch");
		}else {
			//out.print("page before include");
			System.out.println("before include");
			request.setAttribute("errmessage", "Invalid User");
			request.getRequestDispatcher("/WEB-INF/jsp/loginpage.jsp").include(request, response);
			System.out.println("after include");
			//out.print("page after include");
		}
	}
}
