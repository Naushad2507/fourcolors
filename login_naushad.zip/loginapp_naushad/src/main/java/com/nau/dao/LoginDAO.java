package com.nau.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.nau.model.User;
import com.nau.model.UserVO;
import com.nau.util.DBConnection;

public class LoginDAO {
	
	private Connection connection = DBConnection.getConnection();
	public UserVO getUserById(Integer userId) {
		String sql = "select * from loginuser where userid=?";
		try(PreparedStatement ps = connection.prepareStatement(sql)) {
			ps.setInt(1, userId);
			ResultSet rs = ps.executeQuery();
			if(rs.next()) {
				String uname = getUserNameById(userId);
				return new UserVO(uname,rs.getString(2));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	public String getUserNameById(Integer userId) {
		String sql = "select * from userinfo where userid=?";
		try(PreparedStatement ps = connection.prepareStatement(sql)) {
			ps.setInt(1, userId);
			ResultSet rs = ps.executeQuery();
			if(rs.next()) {
				String uname = rs.getString(2);
				System.out.println(uname);
				return uname;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

}
