package com.nau.service;

import com.nau.dao.LoginDAO;
import com.nau.model.User;
import com.nau.model.UserVO;

public class LoginService {
	
	private LoginDAO loginDAO = new LoginDAO();
	
	public String validateUser(User user) {
		
		UserVO userFromDao =  loginDAO.getUserById(user.userId());
		System.out.println(userFromDao);
		if(userFromDao!=null) {
			if(user.password().equals(userFromDao.password())) {
				System.out.println(userFromDao.username());
				return userFromDao.username();
			}
		}
		return null;
	}

}
