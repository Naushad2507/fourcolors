package com.nau;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import org.apache.commons.dbcp2.BasicDataSource;

public class Main {
	
	public static void main(String[] args) throws SQLException {
		
		System.out.println("Main Started");
		
//		String url ="jdbc:mysql://localhost:3306/fourpoints";
//		try {
//			DriverManager.getConnection(url,"naushad","naushad");
//			
//		} catch (SQLException e) {
//			e.printStackTrace();
//		}
		//Connection Pooling
		// C3P 
		BasicDataSource basicDataSource = new BasicDataSource();
		basicDataSource.setUrl("jdbc:mysql://localhost:3306/fourpoints");
		basicDataSource.setUsername("naushad");
		basicDataSource.setPassword("naushad");
		basicDataSource.setInitialSize(10);
		
		Connection con =  basicDataSource.getConnection();
		System.out.println("done");
		con.close();
	}

}
