package com.naushad.dao;

import com.naushad.model.Employee;

public interface EmployeeDAO {
	
	public int saveEmployee(Employee...employees);
	public Employee[] getAllEmployees();
	public Employee getEmployeeById(Integer empId);

}
