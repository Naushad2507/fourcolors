package com.naushad.dao;

import com.naushad.model.Employee;

public class EmployeeDAOImpl implements EmployeeDAO{
	
	private Employee []employees = new Employee[100]; 
	{
		employees[0] = new Employee(111, "Naushad Akhtar");
		employees[1] = new Employee(222, "Rahul Gupta");
		employees[2] = new Employee(333, "Sonam Gupta");
		employees[3] = new Employee(444, "Arti Sharma");
	}
	
	public Employee getEmployeeById(Integer empId) {
		Employee employeeD = null;
		for(Employee employee : this.employees) {
			if(employee.getEmpId()== empId) {
				employeeD = employee;
				break;
			}
		}
		return employeeD;
		
	}
	@Override
	public int saveEmployee(Employee... employees) {
		int employeeCount = 0;
		for(Employee employee : this.employees) {
			if(employee!=null) {
				employeeCount++;
			}
		}
		for(Employee employee : employees) {
			this.employees[employeeCount] = employee;
			employeeCount++;
		}
		return employeeCount;
	}

	@Override
	public Employee[] getAllEmployees() {
		return employees;
	}
	
	

}
