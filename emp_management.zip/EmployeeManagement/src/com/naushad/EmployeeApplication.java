package com.naushad;

import com.naushad.presentation.EmployeeView;

public class EmployeeApplication {
	
	public static void main(String[] args) {
		
		new EmployeeView();
		
	}

}
