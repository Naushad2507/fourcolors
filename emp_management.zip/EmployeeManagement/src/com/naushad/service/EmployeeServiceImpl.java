package com.naushad.service;

import com.naushad.dao.EmployeeDAO;
import com.naushad.dao.EmployeeDAOImpl;
import com.naushad.model.Employee;

public class EmployeeServiceImpl implements EmployeeService{
	
	private EmployeeDAO employeeDAO = new EmployeeDAOImpl();
	
	@Override
	public Employee getEmployeeById(Integer empId) {
		Employee employee = employeeDAO.getEmployeeById(empId);
		System.out.println( "service - getbyid : " + employee);
		return employee;
	}

	@Override
	public int saveEmployee(Employee... employees) {
		for(Employee employee : employees ) {
			System.out.println("service save : " + employee);
			if(employee != null) {
				Employee employeeFromDB = getEmployeeById(employee.getEmpId());
				if(employeeFromDB==null) {
					employee.setEmpName(employee.getEmpName().toUpperCase());
					System.out.println(employee);
					employeeDAO.saveEmployee(employee);
				}else {
					System.out.println("Employee with Id " + employee.getEmpId() + " already exists");
//					employee.setEmpId(0);
//					employee.setEmpName(null);
					//employee = null;
				}
			}
		}
		return 0;
	}

	@Override
	public Employee[] getAllEmployees() {
		
		return employeeDAO.getAllEmployees();
	}

	

}
